// Implement a program to illustrate the use of the ternary operator

import java.util.Scanner;

public class ternary_operator {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter a number: ");
        int num = sc.nextInt();

        String result = (num % 2 == 0) ? "Even" : "Odd";
        System.out.println(num + " is " + result);

        int a = 15, b = 20;
        int max = (a > b) ? a : b;
        System.out.println("Largest of " + a + " and " + b + " is " + max);
        sc.close();
    }
}
